Hello
------------
Hello! 👋 How can I help you today? I can answer questions, explain topics, help with writing or editing, brainstorm ideas, plan tasks, or assist with code. 

A few quick prompts you can try:

* Explain a concept in simple terms
* Draft an email or document
* Brainstorm ideas for a project
* Help debug or review code
* Plan a meal, trip, or schedule

What would you like to do?